(function ($) {
    $(document).ready(function () {
        //mobile menu custom js
        $(".mobile-home-btn").on("click", function () {
            $("html").animate({
                scrollTop: 0
            }, 800);
        });
        $(".mobile-menu-btn").on("click", function () {
            $('ul.mobile-menu').css({
                'bottom': '50px',
                'opacity': '1',
                'transition': 'all .5s',
            });
        });
        $("#close").on("click", function () {
            $('ul.mobile-menu').css({
                'bottom': '-100%',
                'opacity': '0',
                'transition': 'all .8s',
            });
        });
        $("ul.mobile-menu li a").on("click", function () {
            $('ul.mobile-menu').css({
                'bottom': '-100%',
                'opacity': '0',
                'transition': 'all .8s',
            });
        });

        //hero slider
        $('#hero-slider').owlCarousel({
            loop: true,
            margin: 200,
            autoplay: true,
            responsiveClass: true,
            nav: false,
            dots: false,
            mouseDrag: false,
            touchDrag: false,
            responsive: {
                0: {
                    items: 1,
                },
                600: {
                    items: 1,
                },
                1000: {
                    items: 1,
                    loop: true
                }
            }
        });
        //slider animation
        $('#hero-slider').on('translate.owl.carousel', function () {
            $('.item-content h2, .item-content p').removeClass('animated fadeInUp').css('opacity', '0');
            $('.item-1, .item-2, .item-3').css({
                'transform': 'scale(1)',
                'transition': 'all 1s'
            });
        });
        $('#hero-slider').on('translated.owl.carousel', function () {
            $('.item-content h2, .item-content p').addClass('animated fadeInUp').css('opacity', '1');
            $('.item-1, .item-2, .item-3').css({
                'transform': 'scale(1.2)',
                'transition': 'all 1s'
            });
        });

        //sticky menu when scroll
        $(window).on('scroll', function () {
            var scroll = $(window).scrollTop();
            if (scroll > 0) {
                $(".top-bar-section").addClass("sticky_top_section");
            } else {
                $(".top-bar-section").removeClass("sticky_top_section");
            }
        });


        //hospital page sticky navigation on scroll
        $(window).on('scroll', function () {
            var scroll = $(window).scrollTop();
            if (scroll > 500) {
                $(".navigation-control").addClass("sticky_navigation_control");
            } else {
                $(".navigation-control").removeClass("sticky_navigation_control");
            }
        });

        //hospital-feat-img-slider
        $('.hospital-feat-img-slider').owlCarousel({
            loop: false,
            margin: 0,
            autoplay: false,
            responsiveClass: true,
            nav: true,
            dots: false,
            mouseDrag: true,
            touchDrag: true,
            responsive: {
                0: {
                    items: 1,
                },
                600: {
                    items: 1,
                },
                1000: {
                    items: 1
                }
            }
        });
    });
})(jQuery);